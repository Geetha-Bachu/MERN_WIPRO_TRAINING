"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LogCreation = LogCreation;
function LogCreation(target) {
    console.log("Customer class created: ".concat(target.name));
}
