export function LogCreation(target: any) {
  console.log(`Customer class created: ${target.name}`);
}
